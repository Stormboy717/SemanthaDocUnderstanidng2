import csv
import re

regex_pattern = r'^\d{1,2}_'

with open('lookup.csv', 'r') as file:
    reader = csv.reader(file)
    rows = list(reader)

for row in rows:
    row[0] = re.sub(regex_pattern, '', row[0])

with open('lookup.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(rows)

regex_pattern = r'^\d{1,2}_'

with open('distinct_tags.csv', 'r') as file:
    reader = csv.reader(file)
    rows = list(reader)

for row in rows:
    row[0] = re.sub(regex_pattern, '', row[0])

with open('distinct_tags.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(rows)