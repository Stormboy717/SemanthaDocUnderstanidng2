import argparse
import fitz
import csv

def parse_args():
    parser = argparse.ArgumentParser(description='Process a PDF file with tags and export data to CSV.')
    parser.add_argument('input_file', help='Path to the input PDF file')
    return parser.parse_args()

def main():
    args = parse_args()
    input_file = args.input_file

    doc = fitz.open(input_file)

    all_tags = set()
    annotations_data = []  # To store the tags and text for each annotation

    for i in range(doc.page_count):
        page = doc[i]
        for annot in page.annots():
            data = annot.info

            content = data['content']

            # Split the content string based on '\r' (newline)
            content_lines = content.split('\r')

            # Search for the line starting with 'Tags:'
            try:
                tags_line = next(line for line in content_lines if line.startswith('Tags:'))

            except StopIteration:
                print('Tags not found in the annotation.')

            else:
                # Extract the tags part after 'Tags:'
                tags = tags_line.split('Tags:')[1].strip()

                # Split the tags into individual tags
                individual_tags = [tag.strip() for tag in tags.split(',')]

                # Append tags and text data to annotations_data list
                #text = content_lines[-1].split('Text:')[1].strip()  # Extract the Text part

                annotations_data.append({'Tags': ', '.join(individual_tags), })

                # Add the tags to the set of all_tags
                all_tags.update(individual_tags)

    # Export tags and text to a CSV file
    csv_filename = "tags_and_text.csv"
    with open(csv_filename, mode='w', newline='', encoding='utf-8') as file:
        fieldnames = ['Tags', 'Text']
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        for annotation_data in annotations_data:
            writer.writerow(annotation_data)

    # Export distinct list of all tags to another CSV file
    distinct_tags_filename = "distinct_tags.csv"
    with open(distinct_tags_filename, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(['Distinct_Tags'])
        for tag in all_tags:
            writer.writerow([tag])

    print("CSV files exported successfully!")

if __name__ == "__main__":
    main()
