import csv

# Specify the input and output file names
input_file = "output1.csv"
output_file = "output2.csv"

# Read the CSV file and filter rows
filtered_rows = []
with open(input_file, "r") as file:
    reader = csv.reader(file)
    for row in reader:
        if len(row) > 1 and row[1] == "True":
            filtered_rows.append(row)

# Write the filtered rows to a new CSV file
with open(output_file, "w", newline="") as file:
    writer = csv.writer(file)
    writer.writerows(filtered_rows)

print("Filtered rows have been written to", output_file)