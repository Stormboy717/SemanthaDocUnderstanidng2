import pandas as pd

distinct_tags_file = "distinct_tags.csv"
lookup_file = "lookup.csv"
output_file = "combo.csv"

df_distinct_tags = pd.read_csv(distinct_tags_file)
df_lookup = pd.read_csv(lookup_file)

# Create an empty DataFrame to store the results
result_df = pd.DataFrame()

# Iterate through each row in df_distinct_tags
for index, row in df_distinct_tags.iterrows():
    value_to_match = row["Distinct_Tags"]
    matched_rows = df_lookup[df_lookup["Distinct_Tags"].str.contains(value_to_match, case=False)]
    
    if not matched_rows.empty:
        for _, matched_row in matched_rows.iterrows():
            combo_row = pd.concat([row, matched_row])
            result_df = result_df._append(combo_row, ignore_index=True)

# Save the result to the "combo.csv" file
result_df.to_csv(output_file, index=False)
