import pandas as pd

def left_join(csv_file1, csv_file2, output_file):
    # Read CSV files into pandas DataFrames
    data1 = pd.read_csv(csv_file1)
    data2 = pd.read_csv(csv_file2)

    # Perform left join using pandas merge
    joined_data = pd.merge(data1, data2, how='left', left_index=True, right_index=True)

    # Write the joined data to the output CSV file
    joined_data.to_csv(output_file, index=False)

# Provide the file names and output file name
csv_file1 = 'output1.csv'
csv_file2 = 'lookup.csv'
output_file = 'output1.csv'

left_join(csv_file1, csv_file2, output_file)


# Specify the input and output file names
input_file = "output1.csv"
output_file = "output2.csv"

# Read the CSV file and filter rows
filtered_rows = []
with open(input_file, "r") as file:
    reader = csv.reader(file)
    for row in reader:
    #    if len(row) > 1 and row[1] == "True":
         filtered_rows.append(row)

# Write the filtered rows to a new CSV file
with open(output_file, "w", newline="") as file:
    writer = csv.writer(file)
    writer.writerows(filtered_rows)

print("Filtered rows have been written to", output_file)