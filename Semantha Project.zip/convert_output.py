import csv
import re

regex_pattern = r'^\d{1,2}_'

with open('output.txt', 'r') as file:
    reader = csv.reader(file)
    rows = list(reader)

for row in rows:
    row[0] = re.sub(regex_pattern, '', row[0])

with open('output1.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(rows)