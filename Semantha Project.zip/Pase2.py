import argparse
import requests
import semantha_sdk
import fitz
import csv
import numpy as np 
import pandas as pd

def upload_pdf(api, file_path):
    # Uploads the PDF file to the Semantha library
    api = semantha_sdk.login(server_url="https://api.eval1.fra.thingsthinking.systems", key_file="apikey.txt")
    with open(file_path, 'rb') as file:
        my_domain = api.domains("TDSynnex_EN")
        annotated_pdf = api.domains("TDSynnex_EN").references.post_as_pdf(file=file, similaritythreshold=0.8)
        with open((file_path + '_taged.pdf'), 'wb') as file:
            file.write(annotated_pdf.getbuffer())

        
    return annotated_pdf





def read_csv_to_array(file_path):


    # Replace 'your_csv_file.csv' with the path to your CSV file
    csv_file_path = 'distinct_tags.csv'
    
    # Read the CSV file and create a DataFrame
    data_frame = pd.read_csv(csv_file_path)
    
    # Display the DataFrame
    print(data_frame)
    return data_frame
    




import subprocess

def launch_pdf_processing_script(pdf_file_path):
    # Replace 'your_script.py' with the actual name of your Python script
    script_path = 'TagMaker.py'

    # Construct the command to run the script with the PDF file path as an argument
    command = ['python', script_path, pdf_file_path]

    try:
        # Run the command and capture the output and error streams
        result = subprocess.run(command, capture_output=True, text=True)

        # Check the return code to see if the script was successful
        if result.returncode == 0:
            print("PDF processing script executed successfully.")
        else:
            print("PDF processing script failed with the following error:")
            print(result.stderr)

    except Exception as e:
        print("Error while executing the PDF processing script:", e)












print("CSV files exported successfully!")

#def save_tags_locally(document):
#    api = semantha_sdk.login(server_url="https://api.eval1.fra.thingsthinking.systems", key_file="apikey.txt")
#    # Saves the tags found in the document locally
#    tags = api.domains("TDSynnex_EN").tags.get()
#    # Save the tags to a local file or perform any desired operations
#    # with open('tags.json', 'w') as file:#    #     json.dump(tags, file)
#    return tags

def delete_document(api, document_id):
    api = semantha_sdk.login(server_url="https://api.eval1.fra.thingsthinking.systems", key_file="apikey.txt")
    # Deletes the document from the Semantha library
    api.domains("TDSynnex_EN").referencedocuments(document_id).delete()

def reupload_for_each_tag(api, document, tag_df):
    api = semantha_sdk.login(server_url="https://api.eval1.fra.thingsthinking.systems", key_file="apikey.txt")
    my_domain = api.domains("TDSynnex_EN")
    
    # Extract the tag values from the DataFrame
    tags = tag_df['Distinct_Tags'].values
    
    # Re-uploads the document for each tag and downloads the new PDF
    for tag in tags:
        # Upload the document again for the specific tag
        file = open(document, 'rb')
        annotated_pdf = api.domains("TDSynnex_EN").references.post_as_pdf(file=file, similaritythreshold=0.8, tags=tag)
        
        # Save the PDF with the tag value appended to its filename
        pdf_filename_with_tag = f"{document[:-4]}_{tag}.pdf"
        with open(pdf_filename_with_tag, 'wb') as file:
            file.write(annotated_pdf.getbuffer())




def main(file_path):
    # Authenticate with Semantha API
    pdf_tagged_path = str(file_path) + '_taged.pdf'
    api = semantha_sdk.login(server_url="https://api.eval1.fra.thingsthinking.systems", key_file="apikey.txt")

    # Step 1: Upload the PDF to Semantha library
    document = upload_pdf(api, file_path)

    # Step 2: Process the PDF using the external script
    launch_pdf_processing_script(pdf_tagged_path)

    # Step 3: Read the CSV file to get distinct tags
    csv_file_path = 'distinct_tags.csv'
    result_array = read_csv_to_array(csv_file_path)

    # Step 4: Re-upload the document for each tag and download the new PDF
    reupload_for_each_tag(api, file_path, result_array)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process a PDF file with Semantha SDK")
    parser.add_argument("file_path", type=str, help="Path to the PDF file")
    args = parser.parse_args()
    main(args.file_path)



# Authenticate with Semantha API
#file_path = "medical_report-20230719104952.pdf"
#pdf_tagged_path = str(file_path) + '_taged.pdf'
#api = semantha_sdk.login(server_url="https://api.eval1.fra.thingsthinking.systems", key_file="apikey.txt")
# end-points (resp. resources) can be used like objects
#my_domain = api.domains("TDSynnex_EN")
# they may have sub-resources, which can be retrieved as objects as well
#domain_settings = my_domain.settings.get()
#document = upload_pdf("https://api.eval1.fra.thingsthinking.systems/tt-platform-server/api/v3/domains/" , file_path)
# Specify the path to the PDF file

# Step 1: Upload the PDF to Semantha library


#launch_pdf_processing_script(pdf_tagged_path)



# Replace 'your_csv_file.csv' with the path to your CSV file
#csv_file_path = 'distinct_tags.csv'

#result_array = read_csv_to_array(csv_file_path)
#print('array' + result_array)


# Step 2: Save the tags found in the document locally
#tags = save_tags_locally(document)
#@print(document[0].id)
# Step 3: Delete the document from the Semantha library
#delete_document(api, document[0].id)

# Step 4: Re-upload the document for each tag and download the new PDF
#reupload_for_each_tag(api, file_path, result_array)
