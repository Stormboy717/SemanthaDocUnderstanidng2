import pandas as pd

# Read the CSV files
lookup_df = pd.read_csv('lookup.csv')
output1_df = pd.read_csv('output1.csv')

# Remove leading and trailing spaces
lookup_df = lookup_df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
output1_df = output1_df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)

# Perform inner join
key_column_index = 0  # Adjust this index if the key column is at a different position
output2_df = pd.merge(lookup_df, output1_df, left_on=lookup_df.columns[0],
                      right_on=output1_df.columns[0], how='inner')

# Save the joined data to output2.csv
output2_df.to_csv('output2.csv', index=False)
