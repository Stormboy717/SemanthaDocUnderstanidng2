import semantha_sdk
import time
import requests
import argparse
import yaml
import csv

# Parse command-line arguments
parser = argparse.ArgumentParser()
parser.add_argument('--pdf', help='Path to the PDF file')
parser.add_argument('--log', help='Path to the log file')
args = parser.parse_args()


def yaml_to_csv(yaml_file, csv_file):
    with open(yaml_file, 'r') as file:
        data = yaml.safe_load(file)

    with open(csv_file, 'w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=data[0].keys())
        writer.writeheader()
        writer.writerows(data)

# Log in to the Semantha server
api = semantha_sdk.login(server_url="https://api.eval1.fra.thingsthinking.systems", key_file="apikey.txt")

# Specify the domain
my_domain = api.domains("TDSynnex_EN")
# Specify the output file
output_file = "output.txt"
# Create a new submission and inject a PDF file
pdf_path = args.pdf or "./medical_report-20230627144115.pdf"
submission = my_domain.referencedocuments.post(file=open(pdf_path, "rb"), addparagraphsasdocuments=True, tags=("Medic1", "API"))

submission_ids = [doc_info.id for doc_info in submission]
submission_name = [doc_info.name for doc_info in submission]

log_file = args.log or "log.txt"

with open(log_file, "w") as log:
    for id in submission_ids:
        headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer eyJraWQiOiI3MzdlYWI1Yi1mYTViLTQzNjEtYWNjNy04M2UzZTZlMTI1MTYiLCJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2ODcxNjEyOTUsIm5iZiI6MTY4NzE2MTIzNSwianRpIjoiQjhjajYxRktFT3NRSXZiSXF1NUFPUSIsImlzcyI6InRoaW5nc1RISU5LSU5HIEdtYkgiLCJhdWQiOiI2ZWI5ZWRmMi1jNzRkLTRkMWMtOThhMS04NGFhNTk4NjU1ZTkiLCJzdWIiOiJTYW5kcmEuQWhtYWRpZWhAZXZhbDEuZnJhIiwiZXhwIjoxNzE4Njk3Mjk1LCJyb2xlcyI6WyJkLlREU3lubmV4X0VOIiwici5leHBlcnRfdXNlciJdfQ.KS9zZOptU_8cNzqjuGT-dUQWwGL87Ju4aHT6Y_nPZqT6rppHg3a1Wt4KF2_fxBTG695LouzlIw01cUYsQGGa5rENbuISErljd4AreQVtZ54G-NIxD1JQpX20XCct3NxcKQkFxfi1v1xWOaxWndx6J-or1s3BqDHo0twl0BZ8Rxv_w_q3NIuhKp7d9a7uxYgm9YxYXwq0JilvRAT_uDX-hjWwjjJAVmSR-3p12GE7_LZjEKnjb_8ZGDpQr258lJietUeh4y7HXXZHnz61V6m-mhfn5TvQTMswlbKnaPvQmyO6BFj-vWWEmWZVqKuPuxAzrol6aj251hx_v_ahvraGbQ',
        }
        
        url = f'https://api.eval1.fra.thingsthinking.systems/tt-product-server/api/smartcluster/domains/TDSynnex_EN/clusterings/9d0b5b9c-724a-4fd1-9ba1-122271b8fd49'
        
        # Add Doc IDs here
        json_data = {
            'documents': [id],
        }
        print(id + ": submitted")
        cluster_response = requests.put(url=url, headers=headers, json=json_data).json()
        response_data = cluster_response
        
        

time.sleep(30)
for name in submission_name:
    url = f'https://api.eval1.fra.thingsthinking.systems/tt-product-server/api/smartcluster/domains/TDSynnex_EN/clusterings/9d0b5b9c-724a-4fd1-9ba1-122271b8fd49'
    headers = {
        'Accept': 'application/json',
        'Authorization': 'Bearer eyJraWQiOiI3MzdlYWI1Yi1mYTViLTQzNjEtYWNjNy04M2UzZTZlMTI1MTYiLCJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2ODcxNjEyOTUsIm5iZiI6MTY4NzE2MTIzNSwianRpIjoiQjhjajYxRktFT3NRSXZiSXF1NUFPUSIsImlzcyI6InRoaW5nc1RISU5LSU5HIEdtYkgiLCJhdWQiOiI2ZWI5ZWRmMi1jNzRkLTRkMWMtOThhMS04NGFhNTk4NjU1ZTkiLCJzdWIiOiJTYW5kcmEuQWhtYWRpZWhAZXZhbDEuZnJhIiwiZXhwIjoxNzE4Njk3Mjk1LCJyb2xlcyI6WyJkLlREU3lubmV4X0VOIiwici5leHBlcnRfdXNlciJdfQ.KS9zZOptU_8cNzqjuGT-dUQWwGL87Ju4aHT6Y_nPZqT6rppHg3a1Wt4KF2_fxBTG695LouzlIw01cUYsQGGa5rENbuISErljd4AreQVtZ54G-NIxD1JQpX20XCct3NxcKQkFxfi1v1xWOaxWndx6J-or1s3BqDHo0twl0BZ8Rxv_w_q3NIuhKp7d9a7uxYgm9YxYXwq0JilvRAT_uDX-hjWwjjJAVmSR-3p12GE7_LZjEKnjb_8ZGDpQr258lJietUeh4y7HXXZHnz61V6m-mhfn5TvQTMswlbKnaPvQmyO6BFj-vWWEmWZVqKuPuxAzrol6aj251hx_v_ahvraGbQ',
    }
    params = {
        'name': name,
        'maxprobability': '100',
    }
    cluster_response = requests.get(url=url, headers=headers, params=params).json()
    response_data = cluster_response
    
    # Assuming 'yaml_response' contains the YAML response you received
    
    # Parse the YAML response
    response_data = cluster_response
    
    # Check if '/object/clusters' is present in the YAML
    if 'clusters' in response_data:
        clusters = response_data['clusters']

        # Filter the clusters based on the condition
        filtered_clusters = [cluster for cluster in clusters if len(cluster.get('content', [])) > 0]

        # Print the filtered clusters
        with open(output_file, "a") as output:
            for cluster in filtered_clusters:
                output.write(str(cluster.get('orignalName')) + "\n")


